package org.valkyrienskies.mod.mixin.feature.ai.goal.bees;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Position;
import net.minecraft.world.entity.animal.Bee;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.valkyrienskies.mod.common.VSGameUtilsKt;

@Mixin(Bee.BeeEnterHiveGoal.class)
public class MixinEnterHiveGoal {

    @WrapOperation(require = 0, method = "canBeeUse", at = @At(value = "INVOKE", target = "Lnet/minecraft/core/BlockPos;closerToCenterThan(Lnet/minecraft/core/Position;D)Z"))
    private boolean onCloserToCenterThan(BlockPos instance, Position position, double v, Operation<Boolean> original) {
        final Bee bee = VSBeeGoalAccess.getBee(this);
        if (bee == null) {
            return original.call(instance, position, v);
        }
        return original.call(BlockPos.containing(VSGameUtilsKt.toWorldCoordinates(bee.level(), instance)), position, v);
    }
}
