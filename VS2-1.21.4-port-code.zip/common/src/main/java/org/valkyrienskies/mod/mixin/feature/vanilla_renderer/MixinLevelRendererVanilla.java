package org.valkyrienskies.mod.mixin.feature.vanilla_renderer;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.mojang.blaze3d.shaders.Uniform;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexBuffer;
import com.mojang.blaze3d.vertex.VertexFormat;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectList;
import java.util.ListIterator;
import java.util.WeakHashMap;
import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.CompiledShaderProgram;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ViewArea;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Vec3i;
import net.minecraft.util.profiling.Profiler;
import net.minecraft.util.profiling.Zone;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Vector3d;
import org.joml.Vector3dc;
import org.joml.Vector3f;
import org.joml.primitives.AABBd;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.valkyrienskies.core.api.ships.ClientShip;
import org.valkyrienskies.core.api.ships.Ship;
import org.valkyrienskies.core.util.datastructures.BlockPos2ByteOpenHashMap;
import org.valkyrienskies.mod.common.assembly.SeamlessChunksManager;
import org.valkyrienskies.mod.common.VSClientGameUtils;
import org.valkyrienskies.mod.common.VSGameUtilsKt;
import org.valkyrienskies.mod.common.config.ShipRenderer;
import org.valkyrienskies.mod.common.config.ShipRendererKt;
import org.valkyrienskies.mod.common.hooks.VSGameEvents;
import org.valkyrienskies.mod.common.util.VectorConversionsMCKt;
import org.valkyrienskies.mod.mixinducks.client.render.IVSViewAreaMethods;
import org.valkyrienskies.mod.mixinducks.mod_compat.vanilla_renderer.LevelRendererDuck;
import org.valkyrienskies.mod.mixinducks.client.render.LevelRendererVanillaDuck;

@Mixin(value = LevelRenderer.class, priority = 999)
public abstract class MixinLevelRendererVanilla implements LevelRendererDuck, LevelRendererVanillaDuck {
    @Unique
    private final WeakHashMap<ClientShip, ObjectArrayList<SectionRenderDispatcher.RenderSection>> vs$shipRenderChunks = new WeakHashMap<>();
    @Shadow
    private ClientLevel level;

    @Shadow
    @Final
    @Mutable
    private ObjectArrayList<SectionRenderDispatcher.RenderSection> visibleSections;

    @Shadow
    private @Nullable ViewArea viewArea;
    @Shadow
    @Final
    private Minecraft minecraft;

    @Unique
    private BlockPos2ByteOpenHashMap vs$visibileShipChunks = new BlockPos2ByteOpenHashMap();

    /**
     * Fix the distance to render chunks, so that MC doesn't think ship chunks are too far away
     */
    @Redirect(
        method = "compileSections",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/core/BlockPos;distSqr(Lnet/minecraft/core/Vec3i;)D"
        ),
        require = 0
    )
    private double includeShipChunksInNearChunks(final BlockPos b, final Vec3i v) {
        return VSGameUtilsKt.squaredDistanceBetweenInclShips(
            level, b.getX(), b.getY(), b.getZ(), v.getX(), v.getY(), v.getZ()
        );
    }

    @Override
    public void vs$setNeedsFrustumUpdate() {
        // 1.21's renderer invalidation path changed; ship sections are rebuilt and re-discovered
        // through the custom view-area path below, so a no-op is safer than shadowing a stale field.
    }

    @Inject(method = "setupRender", at = @At("HEAD"))
    private void vs$drainShipChunksBeforeRender(final Camera camera, final Frustum frustum, final boolean bl, final boolean bl2,
        final CallbackInfo ci) {
        final SeamlessChunksManager manager = SeamlessChunksManager.get();
        if (manager != null) {
            manager.drainDeferredBatch();
        }
    }

    /**
     * Add ship render chunks to [renderChunks]
     */
    @Inject(
        method = "setupRender",
        at = @At("RETURN")
    )
    private void preSetupRender(final Camera camera, final Frustum frustum, final boolean bl, final boolean bl2, final CallbackInfo ci) {
        // This mixin never gets called for IP dimensions, instead we'll call it manually
        vs$addShipVisibleChunks(frustum);
    }

    @Override
    public void vs$addShipVisibleChunks(final Frustum frustum) {
        // Guard: when another renderer (Sodium / Embeddium) has swapped LevelRenderer's viewArea for
        // its own type, that instance has no IVSViewAreaMethods - bail out instead of throwing
        // ClassCastException and getting the client disconnected.
        if (!(viewArea instanceof final IVSViewAreaMethods shipViewArea)) {
            return;
        }
        for (final ClientShip shipObject : VSGameUtilsKt.getShipObjectWorld(level).getLoadedShips()) {
            if (ShipRendererKt.getShipRenderer(shipObject) != ShipRenderer.VANILLA) {
                continue;
            }
            // Don't bother rendering the ship if its AABB isn't visible to the frustum
            if (!frustum.isVisible(VectorConversionsMCKt.toMinecraft(shipObject.getRenderAABB()))) {
                continue;
            }

            shipObject.getActiveChunksSet().forEach((x, z) -> {
                final LevelChunk levelChunk = level.getChunk(x, z);
                for (int y = level.getMinSectionY(); y < level.getMaxSectionY(); y++) {
                    // Don't add ship chunks more than once
                    if (vs$visibileShipChunks.contains(x, y, z)) {
                        continue;
                    }
                    final LevelChunkSection levelChunkSection = levelChunk.getSection(y - level.getMinSectionY());
                    if (levelChunkSection.hasOnlyAir()) {
                        continue;
                    }

                    SectionRenderDispatcher.RenderSection renderChunk = shipViewArea.vs$getShipRenderSection(x, y, z);
                    if (renderChunk == null) {
                        renderChunk = shipViewArea.vs$getOrCreateShipRenderSection(x, y, z);
                    }
                    if (renderChunk != null) {
                        final AABBd b2 = new AABBd((x << 4) - 6e-1, (y << 4) - 6e-1, (z << 4) - 6e-1,
                            (x << 4) + 15.6, (y << 4) + 15.6, (z << 4) + 15.6)
                            .transform(shipObject.getRenderTransform().getShipToWorld());

                        if (!frustum.isVisible(VectorConversionsMCKt.toMinecraft(b2))) {
                            continue;
                        }

                        vs$shipRenderChunks.computeIfAbsent(shipObject, k -> new ObjectArrayList<>()).add(renderChunk);
                        vs$visibileShipChunks.put(x, y, z, (byte) 1);
                        visibleSections.add(renderChunk);
                    }
                }
            });
        }
    }

    @Inject(
        method = "*",
        at = @At(
            value = "INVOKE",
            target = "Lit/unimi/dsi/fastutil/objects/ObjectArrayList;clear()V"
        )
    )
    private void clearShipChunks(final CallbackInfo ci) {
        vs$shipRenderChunks.forEach((ship, chunks) -> chunks.clear());
        vs$visibileShipChunks = new BlockPos2ByteOpenHashMap();
    }

    // Fixes Block Entities not rendering on ships
    // 1.21.4: renderLevel() no longer calls PoseStack.translate(DDD) directly - the block entity
    // offset moved into LevelRenderer#renderBlockEntities, so the wrap has to target that method.
    @WrapOperation(
        at = @At(
            value = "INVOKE",
            target = "Lcom/mojang/blaze3d/vertex/PoseStack;translate(DDD)V"
        ),
        method = "renderBlockEntities",
        require = 1
    )
    private void fixRenderTransforms(PoseStack instance, double renderX, double renderY, double renderZ, Operation<Void> original, PoseStack ignoredPose, MultiBufferSource.BufferSource bufferSource, MultiBufferSource.BufferSource outlineBuffer, Camera camera, float partialTick) {
        final Vec3 camPos = camera.getPosition();
        final double blockPosX = renderX + camPos.x;
        final double blockPosY = renderY + camPos.y;
        final double blockPosZ = renderZ + camPos.z;
        final Ship ship = VSGameUtilsKt.getShipManagingPos(level, blockPosX, blockPosY, blockPosZ);
        if (ship != null) {
            VSClientGameUtils.transformRenderWithShip(
                ((ClientShip) ship).getRenderTransform(),
                instance,
                blockPosX,
                blockPosY,
                blockPosZ,
                camPos.x,
                camPos.y,
                camPos.z
            );
        } else {
            original.call(instance, renderX, renderY, renderZ);
        }
    }

    // 1.21.4: the renderSectionLayer() calls live inside a lambda of LevelRenderer#addMainPass, which
    // mixin cannot scan. Inject at the tail of renderSectionLayer itself instead: vanilla draws its
    // chunks first, then we draw the ship sections with the exact same layer/state.
    @Inject(method = "renderSectionLayer", at = @At("TAIL"))
    private void vs$renderShipChunks(
        final RenderType renderType,
        final double camX,
        final double camY,
        final double camZ,
        final Matrix4f poseMatrix,
        final Matrix4f projectionMatrix,
        final CallbackInfo ci
    ) {
        if (vs$shipRenderChunks.isEmpty()) {
            return;
        }

        final LevelRenderer self = (LevelRenderer) (Object) this;

        final PoseStack eventPoseStack = new PoseStack();
        eventPoseStack.mulPose(poseMatrix);
        VSGameEvents.INSTANCE.getShipsStartRendering().emit(new VSGameEvents.ShipStartRenderEvent(
            self, renderType, eventPoseStack, camX, camY, camZ, projectionMatrix
        ));

        final PoseStack poseStack = new PoseStack();
        poseStack.mulPose(poseMatrix);

        vs$shipRenderChunks.forEach((ship, chunks) -> {
            poseStack.pushPose();
            final Vector3dc center = ship.getRenderTransform().getWorldToShip().transformPosition(new Vector3d(camX, camY, camZ));
            VSClientGameUtils.transformRenderWithShip(ship.getRenderTransform(), poseStack,
                center.x(), center.y(), center.z(),
                camX, camY, camZ);

            final var event = new VSGameEvents.ShipRenderEvent(
                self, renderType, poseStack, camX, camY, camZ, projectionMatrix, ship, chunks
            );

            VSGameEvents.INSTANCE.getRenderShip().emit(event);
            renderChunkLayer(renderType, poseStack, center.x(), center.y(), center.z(), projectionMatrix, chunks);
            VSGameEvents.INSTANCE.getPostRenderShip().emit(event);

            poseStack.popPose();
        });
    }


    @Unique
    private void renderChunkLayer(final RenderType renderType, final PoseStack poseStack, final double d,
        final double e, final double f,
        final Matrix4f matrix4f, final ObjectList<SectionRenderDispatcher.RenderSection> chunksToRender) {
        RenderSystem.assertOnRenderThread();
        final Zone zone = Profiler.get().zone(() -> "render_" + renderType);
        zone.addText(renderType::toString);
        boolean bl = renderType != RenderType.translucent();
        final ListIterator<SectionRenderDispatcher.RenderSection> objectListIterator = chunksToRender.listIterator(bl ? 0 : chunksToRender.size());
        renderType.setupRenderState();
        final CompiledShaderProgram shaderProgram = RenderSystem.getShader();
        if (shaderProgram == null) {
            renderType.clearRenderState();
            zone.close();
            return;
        }

        shaderProgram.setDefaultUniforms(VertexFormat.Mode.QUADS, poseStack.last().pose(), matrix4f,
            minecraft.getWindow());
        shaderProgram.apply();
        final Uniform uniform = shaderProgram.MODEL_OFFSET;

        while (true) {
            if (bl) {
                if (!objectListIterator.hasNext()) {
                    break;
                }
            } else if (!objectListIterator.hasPrevious()) {
                break;
            }

            final SectionRenderDispatcher.RenderSection renderChunk = bl ? objectListIterator.next() : objectListIterator.previous();
            final SectionRenderDispatcher.CompiledSection compiledSection = renderChunk.getCompiled();
            if (!compiledSection.isEmpty(renderType)) {
                final VertexBuffer vertexBuffer = renderChunk.getBuffer(renderType);
                final BlockPos blockPos = renderChunk.getOrigin();
                if (uniform != null) {
                    uniform.set((float) ((double) blockPos.getX() - d), (float) ((double) blockPos.getY() - e),
                        (float) ((double) blockPos.getZ() - f));
                    uniform.upload();
                }

                vertexBuffer.bind();
                vertexBuffer.draw();
            }
        }

        if (uniform != null) {
            uniform.set(0.0F, 0.0F, 0.0F);
        }

        shaderProgram.clear();
        VertexBuffer.unbind();
        zone.close();
        renderType.clearRenderState();
    }
}
