package org.valkyrienskies.mod.mixin.feature.ai.goal.bees;

import java.lang.reflect.Field;
import net.minecraft.world.entity.animal.Bee;
import org.jetbrains.annotations.Nullable;

/**
 * PORT(1.21.4): the vanilla bee goals keep their owning bee in a field that has no name in the
 * Mojang mappings (`field_2036x` in dev, a different obfuscated name in production), so it cannot
 * be {@code @Shadow}ed - a refmap cannot resolve an unmapped member either. Walking the class
 * hierarchy for the single {@code Bee}-typed field works in both namespaces.
 */
public final class VSBeeGoalAccess {
    private VSBeeGoalAccess() {
    }

    @Nullable
    public static Bee getBee(final Object goal) {
        Class<?> type = goal.getClass();
        while (type != null && type != Object.class) {
            for (final Field field : type.getDeclaredFields()) {
                if (!Bee.class.isAssignableFrom(field.getType())) {
                    continue;
                }
                try {
                    field.setAccessible(true);
                    return (Bee) field.get(goal);
                } catch (final ReflectiveOperationException ignored) {
                    return null;
                }
            }
            type = type.getSuperclass();
        }
        return null;
    }
}
