package org.valkyrienskies.mod.mixin.feature.sound.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.valkyrienskies.core.api.ships.Ship;
import org.valkyrienskies.mod.client.audio.SimpleSoundInstanceOnShip;
import org.valkyrienskies.mod.common.VSGameUtilsKt;

@Mixin(SimpleSoundInstance.class)
public class MixinSimpleSoundInstance {

    @Inject(
        at = @At("HEAD"),
        method = "forJukeboxSong",
        cancellable = true
    )
    private static void forJukeboxSong(final SoundEvent sound, final Vec3 pos,
        final CallbackInfoReturnable<SimpleSoundInstance> cir) {

        final Ship ship = VSGameUtilsKt.getShipManagingPos(Minecraft.getInstance().level, pos.x(), pos.y(), pos.z());
        if (ship != null) {
            cir.setReturnValue(new SimpleSoundInstanceOnShip(
                sound, SoundSource.RECORDS, 4.0F, 1.0F, SoundInstance.createUnseededRandom(), false, 0,
                SoundInstance.Attenuation.LINEAR, pos.x(), pos.y(), pos.z(), ship));
        }
    }

}
