package org.valkyrienskies.mod.mixin.feature.explosions;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.ExplosionDamageCalculator;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerExplosion;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult.Type;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import org.joml.Vector3d;
import org.joml.Vector3dc;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.valkyrienskies.core.api.ships.LoadedServerShip;
import org.valkyrienskies.core.api.ships.ServerShip;
import org.valkyrienskies.core.impl.config.VSCoreConfig;
import org.valkyrienskies.mod.common.VSGameUtilsKt;
import org.valkyrienskies.mod.common.ValkyrienSkiesMod;
import org.valkyrienskies.mod.common.config.VSGameConfig;
import org.valkyrienskies.mod.common.util.GameToPhysicsAdapter;
import org.valkyrienskies.mod.common.util.VectorConversionsMCKt;

/**
 * 1.21.4 port: {@code net.minecraft.world.level.Explosion} became an interface and its implementation moved to
 * {@link ServerExplosion}, where center/radius are immutable. We therefore no longer mutate x/y/z and re-run
 * {@code explode()} on ourselves; instead we spawn translated {@link ServerExplosion} instances around nearby ships.
 */
@Mixin(ServerExplosion.class)
public abstract class MixinExplosion {

    @Shadow
    @Final
    private ServerLevel level;

    @Shadow
    @Final
    private Vec3 center;

    @Shadow
    @Final
    private float radius;

    @Shadow
    @Final
    @Nullable
    private Entity source;

    @Shadow
    @Final
    private DamageSource damageSource;

    @Shadow
    @Final
    private ExplosionDamageCalculator damageCalculator;

    @Shadow
    @Final
    private boolean fire;

    @Shadow
    @Final
    private Explosion.BlockInteraction blockInteraction;

    @Unique
    private static boolean vs$isModifyingExplosion = false;

    @Shadow
    public abstract void explode();

    @Unique
    private void doExplodeForce() {
        final Vector3d originPos = new Vector3d(this.center.x, this.center.y, this.center.z);
        final BlockPos explodePos = BlockPos.containing(originPos.x(), originPos.y(), originPos.z());
        final int radius = (int) Math.ceil(this.radius);
        for (int x = radius; x >= -radius; x--) {
            for (int y = radius; y >= -radius; y--) {
                for (int z = radius; z >= -radius; z--) {
                    final BlockHitResult result = this.level.clip(
                        new ClipContext(Vec3.atCenterOf(explodePos),
                            Vec3.atCenterOf(explodePos.offset(x, y, z)),
                            ClipContext.Block.COLLIDER,
                            ClipContext.Fluid.NONE, CollisionContext.empty()));
                    if (result.getType() == Type.BLOCK) {
                        final BlockPos blockPos = result.getBlockPos();
                        final LoadedServerShip ship = VSGameUtilsKt.getLoadedShipManagingPos(this.level, blockPos);
                        if (ship != null) {
                            final Vector3d forceVector =
                                VectorConversionsMCKt.toJOML(
                                    Vec3.atCenterOf(explodePos)); //Start at center position
                            final Double distanceMult = Math.max(0.5, 1.0 - (this.radius /
                                forceVector.distance(VectorConversionsMCKt.toJOML(Vec3.atCenterOf(blockPos)))));
                            final Double powerMult = Math.max(0.1, this.radius / 4); //TNT blast radius = 4

                            forceVector.sub(VectorConversionsMCKt.toJOML(
                                Vec3.atCenterOf(blockPos))); //Subtract hit block pos to get direction
                            forceVector.normalize();
                            forceVector.mul(-1 *
                                VSGameConfig.SERVER.getExplosionBlastForce()); //Multiply by blast force at center position. Negative because of how we got the direction.
                            forceVector.mul(distanceMult); //Multiply by distance falloff
                            forceVector.mul(powerMult); //Multiply by radius, roughly equivalent to power

                            Vector3dc modelPos = VectorConversionsMCKt.toJOML(Vec3.atCenterOf(blockPos));

                            if (VSCoreConfig.SERVER.getSp().getEnableSplitting()) {
                                //custom split logic for TNT specifically
                                ValkyrienSkiesMod.splitHandler.split(this.level, ship.getId(), (ServerShip ship1) -> ValkyrienSkiesMod.getOrCreateGTPA(ship.getChunkClaimDimension()).applyWorldForceToModelPos(
                                        ship1.getId(), forceVector, ship1.getTransform().getWorldToShip().transformPosition(ship.getTransform().getShipToWorld().transformPosition(modelPos, new Vector3d())
                                    )));
                            }

                            final GameToPhysicsAdapter forceApplier = ValkyrienSkiesMod.getOrCreateGTPA(ship.getChunkClaimDimension());
                            if (forceVector.isFinite()) {
                                forceApplier.applyWorldForceToModelPos(ship.getId(), forceVector,
                                    VectorConversionsMCKt.toJOML(Vec3.atCenterOf(blockPos)));
                            }
                        }
                    }
                }
            }
        }
    }

    @Inject(at = @At("TAIL"), method = "explode")
    private void afterExplode(final CallbackInfo ci) {
        if (vs$isModifyingExplosion) {
            doExplodeForce();
            return;
        }

        vs$isModifyingExplosion = true;
        try {
            final Vec3 c = this.center;
            VSGameUtilsKt.transformToNearbyShipsAndWorld(this.level, c.x, c.y, c.z, (double) this.radius,
                (x, y, z) -> {
                    final ServerExplosion translated = new ServerExplosion(
                        this.level, this.source, this.damageSource, this.damageCalculator,
                        new Vec3(x, y, z), this.radius, this.fire, this.blockInteraction);
                    translated.explode();
                });
        } finally {
            vs$isModifyingExplosion = false;
        }
    }

    @WrapOperation(
        method = "getSeenPercent",
        at = @At(
            value = "NEW",
            target = "Lnet/minecraft/world/level/ClipContext;"
        )
    )
    private static ClipContext getSeenPercent$ClipContext$new(
        Vec3 from,
        Vec3 to,
        final ClipContext.Block blockClip,
        final ClipContext.Fluid fluidClip,
        final Entity source,
        final Operation<ClipContext> operation
    ) {
        if (source != null) {
            final Level level = source.level();
            from = VSGameUtilsKt.toWorldCoordinates(level, from);
            to = VSGameUtilsKt.toWorldCoordinates(level, to);
        }
        return operation.call(from, to, blockClip, fluidClip, source);
    }
}
