package org.valkyrienskies.mod.mixin.feature.bed_fix;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.portal.TeleportTransition;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.valkyrienskies.mod.common.VSGameUtilsKt;

/**
 * PORT(1.21.4): in 1.21.4 findRespawnPositionAndUseSpawnBlock moved from Player to ServerPlayer and
 * returns a TeleportTransition instead of an Optional&lt;Vec3&gt;.
 */
@Mixin(ServerPlayer.class)
public abstract class MixinPlayer {
    /**
     * @author Bunting_chj
     * @reason prevent respawning to shipyard when ship is deleted
     */
    @Inject(
        method = "findRespawnPositionAndUseSpawnBlock(ZLnet/minecraft/world/level/portal/TeleportTransition$PostTeleportTransition;)Lnet/minecraft/world/level/portal/TeleportTransition;",
        at = @At("RETURN"),
        cancellable = true
    )
    private void cancelIfInShipyard(final boolean consume, final TeleportTransition.PostTeleportTransition post,
        final CallbackInfoReturnable<TeleportTransition> cir) {
        final TeleportTransition transition = cir.getReturnValue();
        if (transition == null) {
            return;
        }
        final ServerPlayer self = (ServerPlayer) (Object) this;
        final ServerLevel level = (ServerLevel) self.level();
        final Vec3 pos = transition.position();
        if (VSGameUtilsKt.isBlockInShipyard(level, pos)
            && VSGameUtilsKt.getShipManagingPos(level, pos) == null) {
            cir.setReturnValue(TeleportTransition.missingRespawnBlock(self.server.overworld(), self, post));
        }
    }
}
