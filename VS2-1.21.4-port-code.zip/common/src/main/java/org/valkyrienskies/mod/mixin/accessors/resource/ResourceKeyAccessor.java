package org.valkyrienskies.mod.mixin.accessors.resource;

import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(ResourceKey.class)
public interface ResourceKeyAccessor {
/*
    @Accessor("VALUES")
    static Map<String, ResourceKey<?>> getValues() {
        throw new AssertionError();
    }

 */

    /*
     * PORT(1.21.4): the old @Accessor("getRegistryName") targeted a field that has no name in the
     * dev mappings (field_25137); with the intermediary refmap removed it is unresolvable in
     * production. 1.21.4 exposes ResourceKey#registry() directly, so MixinLevel uses that instead.
     */

    @Invoker
    static <T> ResourceKey<T> callCreate(final ResourceLocation parent, final ResourceLocation location) {
        throw new AssertionError();
    }
}
