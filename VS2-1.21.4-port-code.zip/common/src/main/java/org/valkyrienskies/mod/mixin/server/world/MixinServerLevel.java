package org.valkyrienskies.mod.mixin.server.world;

import static org.valkyrienskies.mod.common.ValkyrienSkiesMod.getVsCore;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import it.unimi.dsi.fastutil.longs.Long2LongOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.BooleanSupplier;
import net.minecraft.core.BlockPos;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.core.Position;
import net.minecraft.core.SectionPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ChunkHolder;
import net.minecraft.server.level.ChunkResult;
import net.minecraft.server.level.ServerChunkCache;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.ai.village.poi.PoiManager;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3d;
import org.joml.Vector3i;
import org.joml.Vector3ic;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.valkyrienskies.core.api.ships.LoadedServerShip;
import org.valkyrienskies.core.api.ships.Wing;
import org.valkyrienskies.core.api.ships.WingManager;
import org.valkyrienskies.core.api.util.AerodynamicUtils;
import org.valkyrienskies.core.impl.config.VSCoreConfig;
import org.valkyrienskies.core.internal.world.VsiServerShipWorld;
import org.valkyrienskies.core.internal.world.chunks.VsiTerrainUpdate;
import org.valkyrienskies.mod.common.VS2ChunkAllocator;
import org.valkyrienskies.mod.common.IShipObjectWorldServerProvider;
import org.valkyrienskies.mod.common.VSGameUtilsKt;
import org.valkyrienskies.mod.common.ValkyrienSkiesMod;
import org.valkyrienskies.mod.common.block.WingBlock;
import org.valkyrienskies.mod.common.config.DimensionParametersResolver;
import org.valkyrienskies.mod.common.util.DragInfoReporter;
import org.valkyrienskies.mod.common.util.VSServerLevel;
import org.valkyrienskies.mod.common.util.VectorConversionsMCKt;
import org.valkyrienskies.mod.mixin.accessors.server.level.ChunkMapAccessor;
import org.valkyrienskies.mod.mixin.accessors.server.level.DistanceManagerAccessor;
import org.valkyrienskies.mod.mixinducks.world.OfLevel;
import org.valkyrienskies.mod.mixinducks.world.level.NoVSLevelDuck;
import org.valkyrienskies.mod.util.McMathUtilKt;

@Mixin(ServerLevel.class)
public abstract class MixinServerLevel implements IShipObjectWorldServerProvider, VSServerLevel {
    @Shadow
    @Final
    private ServerChunkCache chunkSource;

    @Shadow
    @NotNull
    public abstract MinecraftServer getServer();

    @Shadow
    public abstract int sectionsToVillage(SectionPos arg);


    /**
     * Allow block entity ticking (furnaces, hoppers, etc.) on shipyard chunks at FULL status
     * (level 33). Level.tickBlockEntities() gates each ticker on shouldTickBlocksAt(pos),
     * which normally requires BLOCK_TICKING status (level ≤ 32) — so ship chunks held by
     * VS's level-33 tickets would never tick their block entities. The argument is a
     * ChunkPos.asLong (not a BlockPos). As with isPositionTickingWithEntitiesLoaded, we
     * don't guard on getChunkNow because level-33 holders often haven't promoted to the
     * visibleChunkMap — that guard returns null for real ship chunks and breaks ticking.
     */
    @Inject(method = "shouldTickBlocksAt(J)Z", at = @At("HEAD"), cancellable = true)
    private void vs$allowShipyardBlockTicking(long packedChunkPos, CallbackInfoReturnable<Boolean> cir) {
        int chunkX = ChunkPos.getX(packedChunkPos);
        int chunkZ = ChunkPos.getZ(packedChunkPos);
        if (VSGameUtilsKt.isChunkInShipyard(Level.class.cast(this), chunkX, chunkZ)) {
            cir.setReturnValue(true);
        }
    }

    /**
     * Allow shipyard chunks to pass the LevelTicks tick-processing gate.
     *
     * LevelTicks uses isPositionTickingWithEntitiesLoaded as its tickCheck predicate.
     * This method requires BOTH areEntitiesLoaded() AND isPositionTicking() to be true.
     * Ship chunks may not have their entity sections loaded through the normal entity
     * management pipeline, so areEntitiesLoaded() returns false, which prevents ALL
     * scheduled ticks (repeaters, observers, torches, buttons) from being processed.
     */
    @Inject(method = "isPositionTickingWithEntitiesLoaded", at = @At("HEAD"), cancellable = true)
    private void vs$allowShipyardPositionTicking(long packedPos, CallbackInfoReturnable<Boolean> cir) {
        int chunkX = ChunkPos.getX(packedPos);
        int chunkZ = ChunkPos.getZ(packedPos);
        if (VSGameUtilsKt.isChunkInShipyard(Level.class.cast(this), chunkX, chunkZ)) {
            // Unconditional true for shipyard chunks. The getChunkNow() guard we used here
            // was returning null for chunks whose ChunkHolder hadn't promoted to visibleChunkMap
            // (common for level-33 FULL tickets), causing LevelTicks.sortContainersToTick's
            // tickCheck to return false and scheduled ticks to never drain. If we've already
            // registered a tick container for this chunk, the chunk exists — we don't need to
            // re-verify via getChunkNow.
            cir.setReturnValue(true);
        }
    }

    // Enable with -Dvs.traceScheduledTicks=true to emit trace logs for scheduled-tick
    // plumbing on shipyard chunks. Off by default because it's noisy.
    @Unique
    private static final boolean VS$TRACE_SCHEDULED_TICKS =
        Boolean.getBoolean("vs.traceScheduledTicks");

    @Unique
    private static final org.slf4j.Logger VS$TICK_TRACE_LOG =
        org.slf4j.LoggerFactory.getLogger("VS2-TickTrace");

    // Map from ChunkPos to the list of voxel chunks that chunk owns
    @Unique
    private final Map<ChunkPos, List<Vector3ic>> vs$knownChunks = new HashMap<>();

    // Maps chunk pos to number of ticks we have considered unloading the chunk
    @Unique
    private final Long2LongOpenHashMap vs$chunksToUnload = new Long2LongOpenHashMap();

    // How many ticks we wait before unloading a chunk
    @Unique
    private static final long VS$CHUNK_UNLOAD_THRESHOLD = 100;

    @Nullable
    @Override
    public VsiServerShipWorld getShipObjectWorld() {
        return ((IShipObjectWorldServerProvider) getServer()).getShipObjectWorld();
    }

    @Inject(method = "<init>", at = @At("RETURN"))
    void onInit(final CallbackInfo ci) {
        // Fake / wrapped ServerLevels are used by Create, Supplementaries and maybe others.
        if (this instanceof NoVSLevelDuck) return;

        // This only happens when overworld gets loaded on startup, we have a mixin in MixinMinecraftServer for this specific case
        if (getShipObjectWorld() != null) {
            DimensionParametersResolver.Parameters params = DimensionParametersResolver.INSTANCE.getDimensionMap().get(
                VSGameUtilsKt.getDimensionId((ServerLevel) (Object) this)
            );
            if (params != null) {
                getShipObjectWorld().addDimension(
                    VSGameUtilsKt.getDimensionId((ServerLevel) (Object) this),
                    VSGameUtilsKt.getYRange((ServerLevel) (Object) this),
                    params.getGravity(),
                    params.getSeaLevel(),
                    params.getMaxY()
                );
                return;
            }
            getShipObjectWorld().addDimension(
                VSGameUtilsKt.getDimensionId((ServerLevel) (Object) this),
                VSGameUtilsKt.getYRange((ServerLevel) (Object) this),
                McMathUtilKt.getDEFAULT_WORLD_GRAVITY(),
                AerodynamicUtils.DEFAULT_SEA_LEVEL,
                AerodynamicUtils.DEFAULT_MAX
            );
        }
    }

    @Inject(method = "getPoiManager", at = @At("HEAD"))
    void onGetPoiManager(CallbackInfoReturnable<PoiManager> cir) {
        if (chunkSource.getPoiManager() instanceof final OfLevel levelProvider) {
            levelProvider.setLevel((ServerLevel) (Object) this);
        }
    }

    @Inject(method = "isCloseToVillage", at = @At("HEAD"), cancellable = true)
    void preIsCloseToVillage(BlockPos blockPos, int i, CallbackInfoReturnable<Boolean> cir) {
        if (i <= 6) {
            final boolean[] found = {false};
            VSGameUtilsKt.transformToNearbyShipsAndWorld(ServerLevel.class.cast(this), blockPos.getX(), blockPos.getY(), blockPos.getZ(), i * 100.0, (double x, double y, double z) -> {
                found[0] = found[0] || this.sectionsToVillage(SectionPos.of(BlockPos.containing(x, y, z))) <= i;
            });
            if (found[0]) {
                cir.setReturnValue(true);
            }
        }
    }

    /**
     * Include ships in particle distance check. Seems to only be used by /particle
     */
    @WrapOperation(
        method = "sendParticles(Lnet/minecraft/server/level/ServerPlayer;ZDDDLnet/minecraft/network/protocol/Packet;)Z",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/core/BlockPos;closerToCenterThan(Lnet/minecraft/core/Position;D)Z"
        )
    )
    private boolean includeShipsInParticleDistanceCheck(
        final BlockPos player, final Position particle, final double distance,
        final Operation<Boolean> closerToCenterThan) {

        final ServerLevel self = ServerLevel.class.cast(this);
        final LoadedServerShip ship = VSGameUtilsKt.getLoadedShipManagingPos(
            self, (int) particle.x() >> 4, (int) particle.z() >> 4);

        if (ship == null) {
            // vanilla behaviour
            return closerToCenterThan.call(player, particle, distance);
        }

        // in-world position
        final Vector3d posInWorld = ship.getShipToWorld().transformPosition(VectorConversionsMCKt.toJOML(particle));

        return posInWorld.distanceSquared(player.getX(), player.getY(), player.getZ()) < distance * distance;
    }

    @Unique
    private void vs$loadChunk(@NotNull final ChunkAccess worldChunk, final List<VsiTerrainUpdate> voxelShapeUpdates) {
        // Remove the chunk pos from vs$chunksToUnload if its present
        vs$chunksToUnload.remove(worldChunk.getPos().toLong());
        if (!vs$knownChunks.containsKey(worldChunk.getPos())) {
            // Ship chunks at level 33 (FULL) never reach BLOCK_TICKING status in vanilla,
            // so two critical callbacks are missed:
            // 1. registerTickContainerInLevel() — adds tick containers to LevelTicks
            // 2. startTickingChunk() → unpackTicks() — moves saved ticks from pendingTicks
            //    to the active tickQueue so they actually fire
            // Without both, scheduled ticks (repeaters, torches, observers) freeze on reload.
            if (worldChunk instanceof LevelChunk levelChunk) {
                final int cx = worldChunk.getPos().x;
                final int cz = worldChunk.getPos().z;
                if (VSGameUtilsKt.isChunkInShipyard(Level.class.cast(this), cx, cz)) {
                    final ServerLevel self = ServerLevel.class.cast(this);
                    levelChunk.registerTickContainerInLevel(self);
                    self.startTickingChunk(levelChunk);
                    if (VS$TRACE_SCHEDULED_TICKS) {
                        VS$TICK_TRACE_LOG.info(
                            "vs$loadChunk registered tick container for shipyard chunk=({},{}) gameTime={}",
                            cx, cz, self.getGameTime());
                    }
                }
            }

            final List<Vector3ic> voxelChunkPositions = new ArrayList<>();

            final int chunkX = worldChunk.getPos().x;
            final int chunkZ = worldChunk.getPos().z;

            final LevelChunkSection[] chunkSections = worldChunk.getSections();

            for (int sectionY = 0; sectionY < chunkSections.length; sectionY++) {
                final LevelChunkSection chunkSection = chunkSections[sectionY];
                final Vector3ic chunkPos =
                    new Vector3i(chunkX, worldChunk.getSectionYFromSectionIndex(sectionY), chunkZ);
                voxelChunkPositions.add(chunkPos);

                if (chunkSection != null && !chunkSection.hasOnlyAir()) {
                    // Add this chunk to the ground rigid body
                    final VsiTerrainUpdate voxelShapeUpdate =
                        VSGameUtilsKt.toDenseVoxelUpdate(chunkSection, chunkPos);
                    voxelShapeUpdates.add(voxelShapeUpdate);

                    // region Detect wings
                    final ServerLevel thisAsLevel = ServerLevel.class.cast(this);
                    final LoadedServerShip
                        ship = VSGameUtilsKt.getLoadedShipManagingPos(thisAsLevel, chunkX, chunkZ);
                    if (ship != null) {
                        // Sussy cast, but I don't want to expose this directly through the vs-core api
                        final WingManager shipAsWingManager = ship.getWingManager();
                        final MutableBlockPos mutableBlockPos = new MutableBlockPos();
                        for (int x = 0; x < 16; x++) {
                            for (int y = 0; y < 16; y++) {
                                for (int z = 0; z < 16; z++) {
                                    final BlockState blockState = chunkSection.getBlockState(x, y, z);
                                    final int posX = (chunkX << 4) + x;
                                    final int posY = worldChunk.getMinY() + (sectionY << 4) + y;
                                    final int posZ = (chunkZ << 4) + z;
                                    if (blockState.getBlock() instanceof WingBlock) {
                                        mutableBlockPos.set(posX, posY, posZ);
                                        final Wing wing =
                                            ((WingBlock) blockState.getBlock()).getWing(thisAsLevel,
                                                mutableBlockPos, blockState);
                                        if (wing != null) {
                                            shipAsWingManager.setWing(shipAsWingManager.getFirstWingGroupId(),
                                                posX, posY, posZ, wing);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    // endregion
                } else {
                    final VsiTerrainUpdate emptyVoxelShapeUpdate = getVsCore()
                        .newEmptyVoxelShapeUpdate(chunkPos.x(), chunkPos.y(), chunkPos.z(), true);
                    voxelShapeUpdates.add(emptyVoxelShapeUpdate);
                }
            }
            vs$knownChunks.put(worldChunk.getPos(), voxelChunkPositions);
        }
    }

    /**
     * Prevent vanilla from unloading shipyard chunks whose ship is still alive.
     *
     * Ship chunks silently cycle through unload/reload during normal play (vs-core
     * unwatch fires when no player watches; parallel tests can briefly drop tickets).
     * Each unload calls {@code chunk.unregisterTickContainerFromLevel(this)} which
     * discards pending scheduled block/fluid ticks — and that's what breaks buttons,
     * water flow, dispensers, hoppers, etc. on unattended ships.
     *
     * We block the unload HEAD for shipyard chunks whose ship is still in {@code allShips}.
     * When the ship is actually deleted (removed from allShips), {@code ChunkManagement.kt}
     * releases the SHIP_CHUNK ticket and this check falls through → vanilla unload runs.
     */
    @Inject(method = "unload", at = @At("HEAD"), cancellable = true)
    private void vs$keepActiveShipChunksLoaded(final net.minecraft.world.level.chunk.LevelChunk chunk,
                                                final CallbackInfo ci) {
        final ChunkPos pos = chunk.getPos();
        if (!VSGameUtilsKt.isChunkInShipyard(Level.class.cast(this), pos.x, pos.z)) return;
        final ServerLevel self = ServerLevel.class.cast(this);
        if (org.valkyrienskies.mod.common.VSGameUtilsKt.getShipManagingPos(self, pos.x, pos.z) != null) {
            ci.cancel();
        }
    }

    @Inject(method = "tick", at = @At("TAIL"))
    private void postTick(final BooleanSupplier shouldKeepTicking, final CallbackInfo ci) {
        final ServerLevel self = ServerLevel.class.cast(this);
        final VsiServerShipWorld shipObjectWorld = VSGameUtilsKt.getShipObjectWorld(self);
        // Find newly loaded chunks
        final ChunkMapAccessor chunkMapAccessor = (ChunkMapAccessor) chunkSource.chunkMap;

        // Create DenseVoxelShapeUpdate for new loaded chunks
        // Also mark the chunks as loaded in the ship objects
        final List<VsiTerrainUpdate> voxelShapeUpdates = new ArrayList<>();
        final DistanceManagerAccessor distanceManagerAccessor = (DistanceManagerAccessor) chunkSource.chunkMap.getDistanceManager();

        for (final ChunkHolder chunkHolder : chunkMapAccessor.callGetChunks()) {
            final ChunkResult<LevelChunk> worldChunkResult =
                chunkHolder.getTickingChunkFuture().getNow(ChunkHolder.UNLOADED_LEVEL_CHUNK);
            if (vs$knownChunks.containsKey(chunkHolder.getPos())
                || !distanceManagerAccessor.getTickets().containsKey(chunkHolder.getPos().toLong())) {
                continue;
            }

            final LevelChunk[] loadedChunk = new LevelChunk[1];
            worldChunkResult.ifSuccess(chunk -> loadedChunk[0] = chunk);
            if (loadedChunk[0] != null) {
                vs$loadChunk(loadedChunk[0], voxelShapeUpdates);
                continue;
            }

            // Shipyard chunks use FULL tickets and may never produce a ticking future.
            final ChunkPos cp = chunkHolder.getPos();
            if (VSGameUtilsKt.isChunkInShipyard(Level.class.cast(this), cp.x, cp.z)) {
                final LevelChunk cachedChunk = chunkSource.getChunkNow(cp.x, cp.z);
                if (cachedChunk != null) {
                    vs$loadChunk(cachedChunk, voxelShapeUpdates);
                }
            }
        }

        final Iterator<Entry<ChunkPos, List<Vector3ic>>> knownChunkPosIterator = vs$knownChunks.entrySet().iterator();
        while (knownChunkPosIterator.hasNext()) {
            final Entry<ChunkPos, List<Vector3ic>> knownChunkPosEntry = knownChunkPosIterator.next();
            final long chunkPos = knownChunkPosEntry.getKey().toLong();
            // Unload chunks if they don't have tickets or if they're not in the visible chunks
            if ((!distanceManagerAccessor.getTickets().containsKey(chunkPos) || chunkMapAccessor.callGetVisibleChunkIfPresent(chunkPos) == null)) {
                final long ticksWaitingToUnload = vs$chunksToUnload.getOrDefault(chunkPos, 0L);
                if (ticksWaitingToUnload > VS$CHUNK_UNLOAD_THRESHOLD) {
                    // Unload this chunk
                    for (final Vector3ic unloadedChunk : knownChunkPosEntry.getValue()) {
                        final VsiTerrainUpdate deleteVoxelShapeUpdate =
                            getVsCore().newDeleteTerrainUpdate(unloadedChunk.x(), unloadedChunk.y(), unloadedChunk.z());
                        voxelShapeUpdates.add(deleteVoxelShapeUpdate);
                    }
                    knownChunkPosIterator.remove();
                    vs$chunksToUnload.remove(chunkPos);
                } else {
                    vs$chunksToUnload.put(chunkPos, ticksWaitingToUnload + 1);
                }
            }
        }

        // Send new loaded chunks updates to the ship world
        shipObjectWorld.addTerrainUpdates(
            VSGameUtilsKt.getDimensionId(self),
            voxelShapeUpdates
        );

        if (VSCoreConfig.SERVER.getSp().getEnableSplitting()) {
            ValkyrienSkiesMod.splitHandler.tick(ServerLevel.class.cast(this));
        }

        DragInfoReporter.INSTANCE.tick((ServerLevel) (Object) this);

    }

    @Override
    public void removeChunk(final int chunkX, final int chunkZ) {
        final ChunkPos chunkPos = new ChunkPos(chunkX, chunkZ);
        vs$knownChunks.remove(chunkPos);
    }

    @Unique
    private final LongOpenHashSet vs$pendingForcedChunks = new LongOpenHashSet();

    @Override
    public void addPendingForcedChunk(final int chunkX, final int chunkZ) {
        vs$pendingForcedChunks.add(ChunkPos.asLong(chunkX, chunkZ));
    }

    @NotNull
    @Override
    public LongOpenHashSet getPendingForcedChunks() {
        return vs$pendingForcedChunks;
    }
}
