package org.valkyrienskies.mod.common.item

import net.minecraft.network.chat.Component
import net.minecraft.world.entity.player.Player

/**
 * PORT(1.21.4): `Player#sendSystemMessage` was removed in 1.21.2.
 * `displayClientMessage(component, false)` is the replacement for chat output.
 */
@Suppress("unused")
fun Player.sendSystemMessage(component: Component) = this.displayClientMessage(component, false)
