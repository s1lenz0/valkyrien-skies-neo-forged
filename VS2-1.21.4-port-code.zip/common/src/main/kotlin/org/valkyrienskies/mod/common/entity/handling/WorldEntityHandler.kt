package org.valkyrienskies.mod.common.entity.handling

import com.mojang.blaze3d.vertex.PoseStack
import net.minecraft.client.renderer.MultiBufferSource
import net.minecraft.world.entity.Entity
import net.minecraft.world.entity.projectile.AbstractArrow
import net.minecraft.world.entity.projectile.AbstractHurtingProjectile
import net.minecraft.world.entity.projectile.Projectile
import net.minecraft.world.entity.projectile.ProjectileUtil
import org.joml.Vector3d
import org.valkyrienskies.core.api.ships.ClientShip
import org.valkyrienskies.core.api.ships.Ship
import org.valkyrienskies.core.util.component1
import org.valkyrienskies.core.util.component2
import org.valkyrienskies.core.util.component3
import org.valkyrienskies.mod.common.applyShipVelocity
import org.valkyrienskies.mod.common.getShipManaging
import org.valkyrienskies.mod.common.isBlockInShipyard
import org.valkyrienskies.mod.common.toWorldCoordinates
import org.valkyrienskies.mod.common.util.IEntityDraggingInformationProvider
import org.valkyrienskies.mod.common.util.toJOML
import org.valkyrienskies.mod.common.util.toMinecraft
import kotlin.math.atan2
import kotlin.math.sqrt

object WorldEntityHandler : VSEntityHandler {
    override fun freshEntityInShipyard(entity: Entity, ship: Ship) {
        moveEntityFromShipyardToWorld(entity, ship)
    }

    override fun entityRemovedFromShipyard(entity: Entity, ship: Ship) {
        // Do nothing
    }

    override fun <T : Entity> applyRenderTransform(
        ship: ClientShip, entity: T,
        x: Double, y: Double, z: Double,
        rotationYaw: Float, partialTicks: Float,
        matrixStack: PoseStack, buffer: MultiBufferSource, packedLight: Int
    ) {
        // PORT(1.21.4): EntityRenderer#getRenderOffset is gone, draw at the interpolated position directly.
        matrixStack.translate(x, y, z)
    }

    override fun positionSetFromVehicle(self: Entity, vehicle: Entity, x: Double, y: Double, z: Double) {
        if (self.level().isBlockInShipyard(vehicle.position()) && vehicle.getShipManaging() == null) {
            self.stopRiding()
            return
        }
        val (wx, wy, wz) = self.level().toWorldCoordinates(x, y, z)
        self.setPos(wx, wy, wz)
    }

    override fun getTeleportPos(self: Entity, pos: Vector3d): Vector3d {
        return self.level().toWorldCoordinates(pos)
    }

    override fun applyRenderOnMountedEntity(
        ship: ClientShip, self: Entity, passenger: Entity, partialTicks: Float, matrixStack: PoseStack
    ) {
    }

    fun moveEntityFromShipyardToWorld(entity: Entity, ship: Ship) =
        moveEntityFromShipyardToWorld(entity, ship, entity.x, entity.y, entity.z)

    fun moveEntityFromShipyardToWorld(
        entity: Entity, ship: Ship, entityX: Double, entityY: Double, entityZ: Double
    ) {
        val newPos = ship.shipToWorld.transformPosition(Vector3d(entityX, entityY, entityZ))
        entity.setPos(newPos.x, newPos.y, newPos.z)
        entity.xo = entity.x
        entity.yo = entity.y
        entity.zo = entity.z

        val entityVelocity = ship.transform.shipToWorldRotation.transform(entity.deltaMovement.toJOML())

        entity.deltaMovement = entityVelocity.toMinecraft()
        if (entity is Projectile) {
            entity.applyShipVelocity(ship)
        } else {
            (entity as IEntityDraggingInformationProvider).`vs$dragImmediately`(ship)
        }

        val direction : Vector3d
        val yaw : Double
        val pitch : Double

        if (entity is AbstractArrow) {
            direction = entity.deltaMovement.toJOML()
            yaw = atan2(direction.x, direction.z)
            pitch = atan2(direction.y, sqrt((direction.x * direction.x) + (direction.z * direction.z)))
        } else {
            direction = ship.shipToWorld.transformDirection(entity.lookAngle.toJOML())
            yaw = atan2(-direction.x, direction.z)
            pitch = atan2(-direction.y, sqrt((direction.x * direction.x) + (direction.z * direction.z)))
        }

        entity.yRot = (yaw * (180 / Math.PI)).toFloat()
        entity.xRot = (pitch * (180 / Math.PI)).toFloat()
        entity.yRotO = entity.yRot
        entity.xRotO = entity.xRot

        if (entity is AbstractHurtingProjectile) {
            ProjectileUtil.rotateTowardsMovement(entity, 1.0f)
        }
    }
}
