package org.valkyrienskies.mod.common.block

import com.mojang.serialization.MapCodec
import net.minecraft.commands.arguments.EntityAnchorArgument
import net.minecraft.core.BlockPos
import net.minecraft.core.Direction
import net.minecraft.core.registries.Registries
import net.minecraft.resources.ResourceKey
import net.minecraft.resources.ResourceLocation
import net.minecraft.world.InteractionResult
import net.minecraft.world.entity.EntitySpawnReason
import net.minecraft.world.entity.player.Player
import net.minecraft.world.item.context.BlockPlaceContext
import net.minecraft.world.level.BlockGetter
import net.minecraft.world.level.Level
import net.minecraft.world.level.block.Block
import net.minecraft.world.level.block.HorizontalDirectionalBlock
import net.minecraft.world.level.block.SoundType
import net.minecraft.world.level.block.state.BlockState
import net.minecraft.world.level.block.state.StateDefinition
import net.minecraft.world.phys.BlockHitResult
import net.minecraft.world.phys.shapes.CollisionContext
import net.minecraft.world.phys.shapes.VoxelShape
import org.joml.Vector3d
import org.joml.Vector3dc
import org.valkyrienskies.core.util.x
import org.valkyrienskies.core.util.y
import org.valkyrienskies.core.util.z
import org.valkyrienskies.mod.common.ValkyrienSkiesMod
import org.valkyrienskies.mod.common.util.toDoubles

class TestChairBlock() : HorizontalDirectionalBlock(
    Properties.of().strength(1.0f, 120.0f).sound(SoundType.WOOL)
        .setId(ResourceKey.create(Registries.BLOCK, ResourceLocation.fromNamespaceAndPath("valkyrienskies", "test_chair")))
) {
    private val SEAT_AABB: VoxelShape = box(0.0, 0.0, 0.0, 16.0, 8.0, 16.0)

    init {
        registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH))
    }

    override fun createBlockStateDefinition(builder: StateDefinition.Builder<Block, BlockState>) {
        builder.add(FACING)
    }

    override fun getStateForPlacement(ctx: BlockPlaceContext): BlockState? {
        return defaultBlockState()
            .setValue(FACING, ctx.horizontalDirection.opposite)
    }

    override fun getShape(
        state: BlockState, level: BlockGetter, pos: BlockPos, context: CollisionContext
    ): VoxelShape = SEAT_AABB

    override fun useWithoutItem(
        state: BlockState, level: Level, pos: BlockPos, player: Player, blockHitResult: BlockHitResult
    ): InteractionResult {
        if (level.isClientSide) return InteractionResult.SUCCESS
        // PORT(1.21.4): EntityType#create lost its single-arg overload; it now takes a spawn reason.
        val seatEntity = ValkyrienSkiesMod.SHIP_MOUNTING_ENTITY_TYPE.create(level, EntitySpawnReason.MOB_SUMMONED)!!.apply {
            // Put seat at y-offset of .15
            val seatEntityPos: Vector3dc = Vector3d(pos.x + .5, pos.y.toDouble() + .15, pos.z + .5)
            moveTo(seatEntityPos.x, seatEntityPos.y, seatEntityPos.z)
            lookAt(EntityAnchorArgument.Anchor.EYES, state.getValue(FACING).normal.toDoubles().add(position()))
            isController = true
        }

        level.addFreshEntity(seatEntity)
        player.startRiding(seatEntity)
        return InteractionResult.CONSUME
    }

    override fun codec() = CODEC

    companion object {
        val CODEC: MapCodec<TestChairBlock> = simpleCodec { TestChairBlock() }
    }
}
