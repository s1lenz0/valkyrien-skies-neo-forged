package org.valkyrienskies.mod.client

import net.minecraft.client.renderer.entity.EntityRenderer
import net.minecraft.client.renderer.entity.EntityRendererProvider
import net.minecraft.client.renderer.entity.state.EntityRenderState
import net.minecraft.world.entity.Entity

/**
 * PORT(1.21.4): entity renderers are now `EntityRenderer<T extends Entity, S extends EntityRenderState>`
 * and must supply a render state instead of drawing directly from the entity.
 */
class EmptyRenderer(context: EntityRendererProvider.Context) :
    EntityRenderer<Entity, EntityRenderState>(context) {

    override fun createRenderState(): EntityRenderState = EntityRenderState()
}
