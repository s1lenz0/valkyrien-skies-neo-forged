// PORT(1.21.4): the original org.valkyrienskies.mod.compat package was removed because none of
// the mod integrations it wrapped (Create, Sable/EMF, CC:Tweaked, dynmap, Weather2, Sodium hooks,
// ...) have 1.21.4 artifacts. These stubs keep every call site compiling and report "not installed"
// at runtime, which is exactly what the mixin config plugin expects from a vanilla-only install.
// Re-enable the real class per mod once a 1.21.4 build of that mod exists.
package org.valkyrienskies.mod.compat

import net.minecraft.client.multiplayer.ClientLevel
import net.minecraft.server.level.ServerLevel
import net.minecraft.world.entity.Entity
import net.minecraft.world.level.Level

enum class VSRenderer {
    VANILLA,
    OPTIFINE,
    SODIUM
}

object LoadedMods {
    @JvmField
    val sable: Boolean = false

    @JvmField
    val create: Boolean = false

    @JvmField
    val ccTweaked: Boolean = false

    @JvmField
    val emf: Boolean = false

    @JvmField
    val embeddium: Boolean = false

    @JvmField
    val optifine: Boolean = false

    @JvmStatic
    val iris: Boolean = false

    @JvmStatic
    val weather2: Boolean = false

    @JvmStatic
    val immersivePortals: Boolean = false

    @JvmStatic
    val flywheel: FlywheelVersion = FlywheelVersion.NONE

    @JvmStatic
    fun getBluemap(): String = ""

    @JvmStatic
    fun getCreate(): Boolean = false

    @JvmStatic
    fun getOldCreate(): Boolean = false

    @JvmStatic
    fun getAlexCaves(): Boolean = false
    enum class FlywheelVersion {
        V1,
        V06,
        NONE
    }
}

object SableCompat {
    @JvmStatic
    fun isChunkInSublevel(level: Level, chunkX: Int, chunkZ: Int): Boolean = false

    @JvmStatic
    fun isBlockInSublevel(level: Level, blockX: Int, blockY: Int, blockZ: Int): Boolean = false
}

object CreateCompat {
    @JvmStatic
    fun isContraption(entity: Entity): Boolean = false
}

// Sodium's ChunkTracker is not on this port's classpath; these no-ops keep the ClientChunkCache
// mixin harmless whenever Sodium (0.6.x, 1.21.4) is not the active renderer.
object SodiumCompat {
    @JvmStatic
    fun onChunkAdded(level: ClientLevel, x: Int, z: Int) {
    }

    @JvmStatic
    fun onChunkRemoved(level: ClientLevel, x: Int, z: Int) {
    }
}

object Weather2Compat {
    @JvmStatic
    fun tick(level: ServerLevel) {
    }
}
